plugins { id("com.android.application") }

android {
    namespace = "com.hybridathlete.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hybridathlete.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
